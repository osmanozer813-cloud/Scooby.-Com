# SCOOBY.COM — ilk çalışan yerel sürüm

## Dosyalar
- `index.html`: SCOOBY ana sayfası, kişilik testi, Blok Patlat, Şansını Dene, arkadaş testi, İkilemde Kal ve yerel kayıtlar.
- `music.html`: Önceki Hangi Şarkısın? projesinin korunmuş sürümü; 112 soruluk havuzdan 15 soru seçer.

## Çalıştırma
`index.html` dosyasını tarayıcıda açın veya klasörü statik site barındırma hizmetine yükleyin.

## Bu sürümde çalışanlar
- Türkçe/İngilizce/Almanca ana arayüz metinleri; test soruları ve bazı oyun içi metinler şimdilik Türkçe.
- Misafir kullanımında cihaz içi geçmiş, skor ve günlük seri.
- Kıskançlık testi: 100 soruluk havuz, test başına 15 soru.
- Günlük 5 soru: günlük sabit seçim.
- İkilemde Kal: 100 ikilem, her turda 15 seçim.
- Blok Patlat: 8x8 tahta, satır/sütun temizleme, puan ve cihaz içi rekor.
- Arkadaş testi: ayrı 100 soruluk, konuya uygun seçenekli havuz; davet bağlantısında soru ve cevap anahtarı taşınarak farklı cihazlarda da oynanabilir. Bağlantı özel cevapları URL içinde taşır; bunu hassas bilgi için kullanmayın.

## Henüz bağlanmamış çevrim içi özellikler
Gerçek kullanıcı hesapları, bulut eşitleme, herkesin görebildiği canlı istatistikler ve günlük/haftalık küresel liderlik tablosu için Supabase/Firebase gibi bir backend, güvenlik kuralları ve sunucu tarafı doğrulama gerekir. Bu paket bunları varmış gibi göstermez; hesap ekranında durum açıkça belirtilir. Ücretsiz planların limitleri olabilir.

## Yayına almadan önce
- Soru havuzlarını ve sonuç metinlerini editoryal olarak gözden geçirin.
- İngilizce ve Almanca soru/sonuç çevirilerini tamamlayın.
- Arkadaş davet bağlantısı URL uzunluğu ve gizlilik testlerini yapın.
- Gerçek bulut hesabı ve liderlik tablosu isteniyorsa backend yapılandırın.
